export interface Issue {
  id: string;
  title: string;
  description: string;
  category: string;
  status: 'reported' | 'verified' | 'in-progress' | 'resolved';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  reporter: {
    name: string;
    avatar: string;
    xpEarned: number;
    userId?: string;
  };
  votes: number;
  votedUsers: string[];
  createdAt: string;
  updatedAt: string;
  imageUrl?: string;
  aiInsights?: {
    summary: string;
    suggestedSteps: string[];
    priorityScore: number;
    estimatedCost: string;
    escalationPrediction: string;
  };
}

export interface Hero {
  name: string;
  xp: number;
  badge: string;
  reportsCount: number;
  resolutionsCount: number;
}

export interface CommunityStats {
  summary: {
    total: number;
    reported: number;
    verified: number;
    inProgress: number;
    resolved: number;
    resolutionRate: number;
  };
  leaderboard: Hero[];
  predictiveTrend: string;
}

export interface ChatMessage {
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  xp: number;
  badge: string;
  reportsCount: number;
  resolutionsCount: number;
  createdAt: string;
}
