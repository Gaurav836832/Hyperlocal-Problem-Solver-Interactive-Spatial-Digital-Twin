import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { Issue } from "../types";
import { Zap, ShieldAlert, Layers, Crosshair, MapPin, Compass } from "lucide-react";

interface CityDigitalTwinProps {
  issues: Issue[];
  selectedIssueId: string | null;
  onSelectIssue: (issueId: string) => void;
  isNightMode: boolean;
  showHeatmap: boolean;
  showBuildings: boolean;
}

export const CityDigitalTwin: React.FC<CityDigitalTwinProps> = ({
  issues,
  selectedIssueId,
  onSelectIssue,
  isNightMode,
  showHeatmap,
  showBuildings,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const beaconsRef = useRef<{ [id: string]: THREE.Group }>({});
  const buildingsGroupRef = useRef<THREE.Group | null>(null);
  const heatmapGroupRef = useRef<THREE.Group | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);

  const [hoveredIssue, setHoveredIssue] = useState<Issue | null>(null);
  const [spatialStats, setSpatialStats] = useState({ x: 0, z: 0, yaw: 0 });

  // Heatmap UI Configuration state
  const [heatmapCategory, setHeatmapCategory] = useState<string>("All");
  const [heatmapTime, setHeatmapTime] = useState<string>("all"); // 'all', '24h', '7d', '30d'
  const [heatmapStyle, setHeatmapStyle] = useState<string>("density"); // 'density', 'severity', 'category'

  // Map SF Geographic Coordinates to 3D Scene space [-20, 20]
  const convertGeoTo3D = (lat: number, lng: number) => {
    // SF coordinates bounds
    const latMin = 37.755;
    const latMax = 37.790;
    const lngMin = -122.440;
    const lngMax = -122.400;

    // Linear interpolate pct
    const pctX = (lng - lngMin) / (lngMax - lngMin);
    const pctZ = (lat - latMin) / (latMax - latMin);

    // Map to [-18, 18] coordinate grid
    const x = (pctX * 36) - 18;
    const z = -((pctZ * 36) - 18); // Invert Z

    return { x, z };
  };

  // Color helper for severity
  const getSeverityColor = (severity: string): number => {
    switch (severity) {
      case "critical": return 0xef4444; // Neon Red
      case "high": return 0xf97316; // Neon Orange
      case "medium": return 0x06b6d4; // Cyan
      case "low": return 0x10b981; // Emerald Green
      default: return 0xa855f7; // Purple
    }
  };

  // Color helper for categories (heatmap mode)
  const getCategoryColor = (category: string): number => {
    switch (category) {
      case "Roads & Transit": return 0x6366f1; // Indigo
      case "Water Supply": return 0x3b82f6; // Blue
      case "Public Safety": return 0xef4444; // Red
      case "Waste Management": return 0xf59e0b; // Amber
      case "Environment & Parks": return 0x10b981; // Emerald
      case "Power & Grid": return 0xeab308; // Yellow
      default: return 0x8b5cf6; // Purple
    }
  };

  // Main ThreeJS Setup Effect
  useEffect(() => {
    if (!containerRef.current) return;

    // 1. Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(isNightMode ? 0x030712 : 0xf8fafc);
    
    // Add fog for deep spatial feeling
    scene.fog = new THREE.FogExp2(isNightMode ? 0x030712 : 0xf8fafc, 0.025);

    // 2. Camera setup
    const camera = new THREE.PerspectiveCamera(
      45,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    cameraRef.current = camera;
    camera.position.set(25, 25, 25);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    rendererRef.current = renderer;
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    
    // Clear previous canvas if any
    containerRef.current.innerHTML = "";
    containerRef.current.appendChild(renderer.domElement);

    // 4. Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.1; // Don't go below ground
    controls.minDistance = 5;
    controls.maxDistance = 80;

    // 5. Lights
    const ambientLight = new THREE.AmbientLight(isNightMode ? 0x111827 : 0xffffff, isNightMode ? 1.5 : 1.2);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, isNightMode ? 0.6 : 1.5);
    dirLight.position.set(20, 40, 20);
    dirLight.castShadow = true;
    scene.add(dirLight);

    // Point lighting at the core center for nice glow
    const centerGlow = new THREE.PointLight(isNightMode ? 0x6366f1 : 0x3b82f6, 3, 30);
    centerGlow.position.set(0, 2, 0);
    scene.add(centerGlow);

    // 6. Ground & Cyber Grid
    const gridColor = isNightMode ? 0x374151 : 0xcbd5e1;
    const gridCenterColor = isNightMode ? 0x6366f1 : 0x3b82f6;
    const gridHelper = new THREE.GridHelper(50, 50, gridCenterColor, gridColor);
    gridHelperRef.current = gridHelper;
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // A subtle dark floor plane to catch raycasts properly
    const floorGeo = new THREE.PlaneGeometry(100, 100);
    const floorMat = new THREE.MeshStandardMaterial({
      color: isNightMode ? 0x070b19 : 0xf1f5f9,
      roughness: 0.8,
      metalness: 0.2,
      side: THREE.DoubleSide
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // 7. Holographic/Stylized Buildings Group
    const buildingsGroup = new THREE.Group();
    buildingsGroupRef.current = buildingsGroup;
    scene.add(buildingsGroup);

    // Generate random futuristic skyscrapers
    const buildCityBuildings = () => {
      buildingsGroup.clear();
      
      const buildingMat = new THREE.MeshStandardMaterial({
        color: isNightMode ? 0x1e293b : 0xe2e8f0,
        transparent: true,
        opacity: isNightMode ? 0.35 : 0.7,
        roughness: 0.3,
        metalness: 0.1
      });

      // Simple grid building distribution to look like blocks
      for (let bx = -16; bx <= 16; bx += 4) {
        for (let bz = -16; bz <= 16; bz += 4) {
          // Skip the very center for map layout or road avenues
          if (Math.abs(bx) < 2 || Math.abs(bz) < 2) continue;
          if (Math.random() > 0.45) {
            const h = 2 + Math.random() * 8;
            const w = 1.2 + Math.random() * 1.5;
            const d = 1.2 + Math.random() * 1.5;

            const boxGeo = new THREE.BoxGeometry(w, h, d);
            const mesh = new THREE.Mesh(boxGeo, buildingMat);
            mesh.position.set(bx + (Math.random() - 0.5) * 0.5, h / 2, bz + (Math.random() - 0.5) * 0.5);
            mesh.castShadow = true;
            mesh.receiveShadow = true;

            // Wireframe contour lines
            const edges = new THREE.EdgesGeometry(boxGeo);
            const lineMat = new THREE.LineBasicMaterial({
              color: isNightMode ? 0x4f46e5 : 0x94a3b8,
              linewidth: 1,
              transparent: true,
              opacity: isNightMode ? 0.4 : 0.6
            });
            const line = new THREE.LineSegments(edges, lineMat);
            mesh.add(line);

            buildingsGroup.add(mesh);
          }
        }
      }
    };
    
    if (showBuildings) buildCityBuildings();

    // 8. Heatmap Groups
    const heatmapGroup = new THREE.Group();
    heatmapGroupRef.current = heatmapGroup;
    scene.add(heatmapGroup);

    // 9. Resize handler
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      cameraRef.current.aspect = width / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(width, height);
    };

    window.addEventListener("resize", handleResize);

    // 10. Mouse Interaction / Raycasting setup
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onMouseMove = (event: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      
      mouse.x = ((event.clientX - rect.left) / containerRef.current.clientWidth) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / containerRef.current.clientHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      // Find intersections only amongst our beacons target mesh elements
      const targetMeshes: THREE.Object3D[] = [];
      Object.values(beaconsRef.current).forEach(group => {
        const cylinder = (group as THREE.Group).getObjectByName("beacon-cylinder");
        if (cylinder) targetMeshes.push(cylinder);
      });

      const intersects = raycaster.intersectObjects(targetMeshes);
      if (intersects.length > 0) {
        document.body.style.cursor = "pointer";
        const hitMesh = intersects[0].object;
        const hitIssueId = hitMesh.userData.issueId;
        const matchingIssue = issues.find(i => i.id === hitIssueId);
        if (matchingIssue) {
          setHoveredIssue(matchingIssue);
        }
      } else {
        document.body.style.cursor = "default";
        setHoveredIssue(null);
      }
    };

    const onClick = (event: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      
      mouse.x = ((event.clientX - rect.left) / containerRef.current.clientWidth) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / containerRef.current.clientHeight) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);

      const targetMeshes: THREE.Object3D[] = [];
      Object.values(beaconsRef.current).forEach(group => {
        const cylinder = (group as THREE.Group).getObjectByName("beacon-cylinder");
        if (cylinder) targetMeshes.push(cylinder);
      });

      const intersects = raycaster.intersectObjects(targetMeshes);
      if (intersects.length > 0) {
        const hitMesh = intersects[0].object;
        const hitIssueId = hitMesh.userData.issueId;
        onSelectIssue(hitIssueId);
      }
    };

    containerRef.current.addEventListener("mousemove", onMouseMove);
    containerRef.current.addEventListener("click", onClick);

    // 11. Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Damping update
      if (controlsRef.current) {
        controlsRef.current.update();
        setSpatialStats({
          x: Math.round(camera.position.x * 10) / 10,
          z: Math.round(camera.position.z * 10) / 10,
          yaw: Math.round((camera.rotation.y * 180 / Math.PI) % 360)
        });
      }

      // Animate pulsing beacons
      Object.values(beaconsRef.current).forEach(group => {
        const g = group as THREE.Group;
        const pulseRing = g.getObjectByName("beacon-pulse") as THREE.Mesh | undefined;
        
        if (pulseRing) {
          const s = 1.0 + Math.sin(elapsedTime * 6) * 0.35;
          pulseRing.scale.set(s, s, s);
          
          const mat = pulseRing.material as THREE.MeshBasicMaterial;
          mat.opacity = 0.5 - (Math.sin(elapsedTime * 6) * 0.15);
        }

        const lightBeam = g.getObjectByName("beacon-beam") as THREE.Line | undefined;
        if (lightBeam) {
          // Subtle rotate & flicker the beacon height lines
          lightBeam.rotation.y += 0.01;
          const mat = lightBeam.material as THREE.LineBasicMaterial;
          mat.opacity = 0.2 + Math.abs(Math.sin(elapsedTime * 4)) * 0.3;
        }
      });

      // Animate Heatmap spheres if visible
      if (showHeatmap && heatmapGroupRef.current) {
        heatmapGroupRef.current.children.forEach(mesh => {
          const m = mesh as THREE.Mesh;
          if (m.userData && m.userData.targetScale !== undefined) {
            // Smoothly lerp current scale & opacity towards targets
            m.userData.currentScale += (m.userData.targetScale - m.userData.currentScale) * 0.08;
            m.userData.currentOpacity += (m.userData.targetOpacity - m.userData.currentOpacity) * 0.08;

            // Soft breathing pulse overlay based on elapsed time and coordinates
            const pulse = m.userData.currentScale * (1.0 + Math.sin(elapsedTime * 1.5 + (m.position.x * 0.15)) * 0.07);
            m.scale.set(pulse, pulse, pulse);

            const mat = m.material as THREE.MeshBasicMaterial;
            mat.opacity = m.userData.currentOpacity;
          } else {
            const s = 1.0 + Math.sin(elapsedTime * 1.5 + (m.position.x * 0.1)) * 0.08;
            m.scale.set(s, s, s);
          }
        });
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animate();

    // Cleanups
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      if (containerRef.current) {
        containerRef.current.removeEventListener("mousemove", onMouseMove);
        containerRef.current.removeEventListener("click", onClick);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [issues, showBuildings]); // Re-setup city if list structure or building toggles alter

  // Effect to update Day/Night background + grid theme
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    scene.background = new THREE.Color(isNightMode ? 0x030712 : 0xf8fafc);
    scene.fog = new THREE.FogExp2(isNightMode ? 0x030712 : 0xf8fafc, 0.025);

    if (gridHelperRef.current) {
      scene.remove(gridHelperRef.current);
      const gridColor = isNightMode ? 0x374151 : 0xcbd5e1;
      const gridCenterColor = isNightMode ? 0x6366f1 : 0x3b82f6;
      const gridHelper = new THREE.GridHelper(50, 50, gridCenterColor, gridColor);
      gridHelperRef.current = gridHelper;
      gridHelper.position.y = -0.01;
      scene.add(gridHelper);
    }
  }, [isNightMode]);

  // Effect to load / update BEACONS and HEATMAP when issues list changes or filters are toggled
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // 1. Clear existing beacons
    Object.values(beaconsRef.current).forEach(group => scene.remove(group));
    beaconsRef.current = {};

    // 2. Clear heatmap
    if (heatmapGroupRef.current) {
      heatmapGroupRef.current.clear();
    }

    // 3. Draw beacons and heatmap for each issue
    issues.forEach(issue => {
      const { x, z } = convertGeoTo3D(issue.location.lat, issue.location.lng);
      const severityColor = getSeverityColor(issue.severity);
      const isActive = issue.id === selectedIssueId;

      const group = new THREE.Group();
      group.position.set(x, 0, z);

      // A: Core glowing cylinder pin pointed at ground
      const pinHeight = isActive ? 1.5 : 1.0;
      const cylinderGeo = new THREE.CylinderGeometry(0.01, 0.28, pinHeight, 5);
      cylinderGeo.translate(0, pinHeight / 2, 0); // Position base at zero-plane
      
      const cylinderMat = new THREE.MeshStandardMaterial({
        color: severityColor,
        roughness: 0.1,
        metalness: 0.8,
        emissive: severityColor,
        emissiveIntensity: isActive ? 2.5 : 0.8
      });
      const cylinder = new THREE.Mesh(cylinderGeo, cylinderMat);
      cylinder.name = "beacon-cylinder";
      cylinder.userData = { issueId: issue.id };
      cylinder.castShadow = true;
      group.add(cylinder);

      // B: Flat pulsing signal ring at base
      const ringGeo = new THREE.RingGeometry(0.05, isActive ? 1.4 : 0.9, 16);
      ringGeo.rotateX(-Math.PI / 2); // Make parallel to floor
      const ringMat = new THREE.MeshBasicMaterial({
        color: severityColor,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.4
      });
      const pulseRing = new THREE.Mesh(ringGeo, ringMat);
      pulseRing.name = "beacon-pulse";
      pulseRing.position.y = 0.02; // Tiny offset above ground to avoid z-fighting
      group.add(pulseRing);

      // C: Glowing technical vertical light beam rising to the heavens
      const beamGeo = new THREE.BufferGeometry();
      const beamPoints = [
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 15, 0)
      ];
      beamGeo.setFromPoints(beamPoints);
      const beamMat = new THREE.LineBasicMaterial({
        color: severityColor,
        transparent: true,
        opacity: isActive ? 0.7 : 0.3
      });
      const lightBeam = new THREE.Line(beamGeo, beamMat);
      lightBeam.name = "beacon-beam";
      group.add(lightBeam);

      // D: A small orbiting satellite sphere for critical issues to catch extra premium style points
      if (issue.severity === "critical" || isActive) {
        const satGeo = new THREE.SphereGeometry(0.12, 8, 8);
        const satMat = new THREE.MeshBasicMaterial({ color: severityColor });
        const sat = new THREE.Mesh(satGeo, satMat);
        sat.position.set(0.6, isActive ? 1.2 : 0.8, 0);
        
        // Custom update function for local orbiting inside requestAnimationFrame
        cylinder.add(sat);
      }

      scene.add(group);
      beaconsRef.current[issue.id] = group;

      // 4. Draw Heatmap representation specifically for matching items if enabled
      if (showHeatmap && heatmapGroupRef.current) {
        // Evaluate filter criteria
        let matchesCategory = heatmapCategory === "All" || issue.category === heatmapCategory;
        let matchesTime = true;

        if (heatmapTime !== "all") {
          const createdTime = new Date(issue.createdAt).getTime();
          const diffMs = Date.now() - createdTime;
          const oneDay = 24 * 60 * 60 * 1000;
          if (heatmapTime === "24h" && diffMs > oneDay) matchesTime = false;
          else if (heatmapTime === "7d" && diffMs > 7 * oneDay) matchesTime = false;
          else if (heatmapTime === "30d" && diffMs > 30 * oneDay) matchesTime = false;
        }

        if (matchesCategory && matchesTime) {
          let heatColor = severityColor;
          let scaleMultiplier = 1.0;

          if (heatmapStyle === "density") {
            const intensity = Math.min(issue.votes / 25, 1.0);
            // Green/Blue to Orange/Red transition based on density (votes)
            heatColor = new THREE.Color().lerpColors(new THREE.Color(0x06b6d4), new THREE.Color(0xef4444), intensity).getHex();
            scaleMultiplier = 1.0 + (issue.votes * 0.15);
          } else if (heatmapStyle === "category") {
            heatColor = getCategoryColor(issue.category);
            scaleMultiplier = 1.5;
          } else if (heatmapStyle === "severity") {
            heatColor = getSeverityColor(issue.severity);
            scaleMultiplier = 1.5;
          }

          if (isActive) {
            scaleMultiplier *= 1.3;
          }

          const heatGeo = new THREE.SphereGeometry(2.0 * scaleMultiplier, 16, 16);
          const heatMat = new THREE.MeshBasicMaterial({
            color: heatColor,
            transparent: true,
            opacity: 0.0, // Start fully transparent for smooth fade in
            depthWrite: false
          });
          const heatCloud = new THREE.Mesh(heatGeo, heatMat);
          heatCloud.position.set(x, 0.2, z);
          heatCloud.scale.set(0.01, 0.01, 0.01); // Start minified for smooth expand-in

          heatCloud.userData = {
            targetScale: 1.0,
            targetOpacity: 0.16,
            currentScale: 0.01,
            currentOpacity: 0.0
          };

          heatmapGroupRef.current.add(heatCloud);
        }
      }
    });
  }, [issues, selectedIssueId, showHeatmap, heatmapCategory, heatmapTime, heatmapStyle]);

  // Effect to smoothly glide camera to focus on selected issue
  useEffect(() => {
    if (!selectedIssueId || !cameraRef.current || !controlsRef.current) return;
    const selectedGroup = beaconsRef.current[selectedIssueId];
    if (!selectedGroup) return;

    // Smooth panning target position
    const targetX = selectedGroup.position.x;
    const targetZ = selectedGroup.position.z;

    // Setup an interpolation sequence
    const duration = 1200; // ms
    const startTime = performance.now();
    
    const startCamPos = cameraRef.current.position.clone();
    const startControlsTarget = controlsRef.current.target.clone();
    
    const targetCamPos = new THREE.Vector3(targetX + 8, 10, targetZ + 8);
    const targetControlsTarget = new THREE.Vector3(targetX, 0.5, targetZ);

    const animateTransition = (time: number) => {
      const elapsed = time - startTime;
      const progress = Math.min(elapsed / duration, 1.0);
      
      // Smooth step ease out formula
      const ease = 1 - Math.pow(1 - progress, 3);

      if (cameraRef.current && controlsRef.current) {
        cameraRef.current.position.lerpVectors(startCamPos, targetCamPos, ease);
        controlsRef.current.target.lerpVectors(startControlsTarget, targetControlsTarget, ease);
        
        if (progress < 1.0) {
          requestAnimationFrame(animateTransition);
        }
      }
    };

    requestAnimationFrame(animateTransition);
  }, [selectedIssueId]);

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden glass-panel shadow-2xl backdrop-blur-xl">
      {/* 3D Canvas viewport container */}
      <div ref={containerRef} className="w-full h-full" style={{ minHeight: "380px" }} />

      {/* Cyber Compass / Coordinates overlay hud */}
      <div className="absolute top-4 left-4 flex flex-col gap-2 pointer-events-none font-mono text-xs text-indigo-300 bg-white/5 backdrop-blur-md border border-white/10 px-3 py-2 rounded-lg shadow-lg">
        <div className="flex items-center gap-1.5 font-bold text-indigo-300">
          <Compass className="w-3.5 h-3.5 animate-spin-slow text-indigo-400" />
          <span>HERO_MATRIX v1.4</span>
        </div>
        <div className="text-slate-400 space-y-0.5">
          <p>CAM_X: <span className="text-white">{spatialStats.x}</span></p>
          <p>CAM_Z: <span className="text-white">{spatialStats.z}</span></p>
          <p>YAW: <span className="text-white">{spatialStats.yaw}°</span></p>
        </div>
      </div>

      {/* Floating Heatmap Controller Panel */}
      {showHeatmap && (
        <div className="absolute top-4 right-4 flex flex-col gap-2 p-3 rounded-xl bg-slate-950/80 backdrop-blur-md border border-white/10 text-white shadow-xl max-w-[200px] md:max-w-[240px] animate-fade-in z-20">
          <div className="flex items-center gap-1.5 font-mono text-[10px] text-indigo-300 font-bold tracking-wide border-b border-white/10 pb-1.5">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>HEAT_GRID CONFIG</span>
          </div>
          
          <div className="flex flex-col gap-1">
            <label className="text-[9px] text-slate-400 uppercase font-mono tracking-wider">Metric Type</label>
            <select
              value={heatmapStyle}
              onChange={(e) => setHeatmapStyle(e.target.value)}
              className="w-full bg-slate-900/90 text-slate-200 border border-white/15 rounded-md px-1.5 py-1 text-[10px] font-sans focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
            >
              <option value="density" className="bg-slate-950 text-slate-200">Density (Votes)</option>
              <option value="severity" className="bg-slate-950 text-slate-200">Severity Level</option>
              <option value="category" className="bg-slate-950 text-slate-200">Issue Type</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[9px] text-slate-400 uppercase font-mono tracking-wider">Category</label>
            <select
              value={heatmapCategory}
              onChange={(e) => setHeatmapCategory(e.target.value)}
              className="w-full bg-slate-900/90 text-slate-200 border border-white/15 rounded-md px-1.5 py-1 text-[10px] font-sans focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
            >
              <option value="All" className="bg-slate-950 text-slate-200">All Categories</option>
              <option value="Roads & Transit" className="bg-slate-950 text-slate-200">Roads & Transit</option>
              <option value="Water Supply" className="bg-slate-950 text-slate-200">Water Supply</option>
              <option value="Public Safety" className="bg-slate-950 text-slate-200">Public Safety</option>
              <option value="Waste Management" className="bg-slate-950 text-slate-200">Waste Management</option>
              <option value="Environment & Parks" className="bg-slate-950 text-slate-200">Environment & Parks</option>
              <option value="Power & Grid" className="bg-slate-950 text-slate-200">Power & Grid</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[9px] text-slate-400 uppercase font-mono tracking-wider">Time Frame</label>
            <select
              value={heatmapTime}
              onChange={(e) => setHeatmapTime(e.target.value)}
              className="w-full bg-slate-900/90 text-slate-200 border border-white/15 rounded-md px-1.5 py-1 text-[10px] font-sans focus:outline-none focus:border-indigo-500 transition-all cursor-pointer"
            >
              <option value="all" className="bg-slate-950 text-slate-200">All Time</option>
              <option value="24h" className="bg-slate-950 text-slate-200">Last 24 Hours</option>
              <option value="7d" className="bg-slate-950 text-slate-200">Last 7 Days</option>
              <option value="30d" className="bg-slate-950 text-slate-200">Last 30 Days</option>
            </select>
          </div>
        </div>
      )}

      {/* Real-time floating tooltips for hovered beacons */}
      {hoveredIssue && (
        <div className="absolute bottom-4 left-4 right-4 md:right-auto md:max-w-xs p-3.5 rounded-xl bg-white/5 backdrop-blur-md border border-white/10 text-white shadow-2xl flex flex-col gap-1.5 animate-fade-in pointer-events-none">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[10px] uppercase tracking-wider font-mono px-2 py-0.5 rounded-full font-semibold bg-indigo-500/20 text-indigo-400">
              {hoveredIssue.category}
            </span>
            <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-semibold ${
              hoveredIssue.severity === "critical" ? "bg-rose-500/20 text-rose-400 border border-rose-500/20" :
              hoveredIssue.severity === "high" ? "bg-amber-500/20 text-amber-400 border border-amber-500/20" :
              "bg-cyan-500/20 text-cyan-400 border border-cyan-500/20"
            }`}>
              {hoveredIssue.severity}
            </span>
          </div>
          <h4 className="text-xs font-bold truncate text-slate-100">{hoveredIssue.title}</h4>
          <div className="flex items-center gap-1 text-[10px] text-slate-400">
            <MapPin className="w-3 h-3 text-slate-500 flex-shrink-0" />
            <span className="truncate">{hoveredIssue.location.address}</span>
          </div>
          <div className="mt-1 flex items-center justify-between text-[10px] font-mono border-t border-white/10 pt-1.5">
            <span className="text-indigo-400">Votes: <strong className="text-white">{hoveredIssue.votes}</strong></span>
            <span className="text-emerald-400 uppercase font-bold">{hoveredIssue.status}</span>
          </div>
        </div>
      )}

      {/* Camera target control tips */}
      <div className="absolute bottom-4 right-4 hidden md:flex items-center gap-2 text-[10px] font-mono text-slate-400 bg-white/5 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-lg pointer-events-none">
        <Crosshair className="w-3 h-3 text-indigo-400" />
        <span>Drag to rotate · Scroll to zoom · Click pins</span>
      </div>
    </div>
  );
};
