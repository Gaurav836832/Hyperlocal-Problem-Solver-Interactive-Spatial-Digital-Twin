import React, { useState, useRef } from "react";
import { Upload, MapPin, Sparkles, Navigation, AlertCircle, FileText, CheckCircle2 } from "lucide-react";
import { Issue } from "../types";

interface ReportStudioProps {
  onIssueCreated: (newIssue: Issue) => void;
  isNightMode: boolean;
}

export const ReportStudio: React.FC<ReportStudioProps> = ({ onIssueCreated, isNightMode }) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("Roads & Transit");
  const [address, setAddress] = useState("");
  const [lat, setLat] = useState(37.7749);
  const [lng, setLng] = useState(-122.4194);
  const [reporterName, setReporterName] = useState("");
  const [image, setImage] = useState<string | null>(null);
  
  const [isDragOver, setIsDragOver] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStep, setSubmitStep] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const categories = [
    "Roads & Transit",
    "Water Supply",
    "Public Safety",
    "Waste Management",
    "Environment & Parks",
    "Power & Grid"
  ];

  // Geolocation trigger
  const triggerGeolocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // If in real location, use it. But for our SF Digital Twin Map context, let's keep them slightly within SF bounds
          // so it renders beautifully in 3D: lat around 37.755 - 37.790, lng around -122.440 to -122.400
          const userLat = position.coords.latitude;
          const userLng = position.coords.longitude;
          
          // Check if user is in SF. If not, simulate random coordinate inside SF bounds for excellent 3D visual mapping!
          if (userLat > 37.70 && userLat < 37.85 && userLng > -122.50 && userLng < -122.35) {
            setLat(userLat);
            setLng(userLng);
            setAddress("Your Current SF Coordinate");
          } else {
            // Random coordinate within SF 3D bounds
            const randomSF = generateRandomSFCoords();
            setLat(randomSF.lat);
            setLng(randomSF.lng);
            setAddress(randomSF.address);
          }
        },
        () => {
          // Fallback to random SF coords
          const randomSF = generateRandomSFCoords();
          setLat(randomSF.lat);
          setLng(randomSF.lng);
          setAddress(randomSF.address);
        }
      );
    } else {
      const randomSF = generateRandomSFCoords();
      setLat(randomSF.lat);
      setLng(randomSF.lng);
      setAddress(randomSF.address);
    }
  };

  const generateRandomSFCoords = () => {
    // Generates coordinates inside SF digital twin bounds
    const lats = [37.7652, 37.7812, 37.7715, 37.7845, 37.7591];
    const lngs = [-122.4210, -122.4115, -122.4350, -122.4045, -122.4180];
    const names = [
      "Dolores Heights, San Francisco, CA",
      "Union Square Block, San Francisco, CA",
      "Lower Haight Sidewalk, San Francisco, CA",
      "SoMa Corridor Alley, San Francisco, CA",
      "Mission District Walkway, San Francisco, CA"
    ];
    const index = Math.floor(Math.random() * lats.length);
    return {
      lat: lats[index] + (Math.random() - 0.5) * 0.005,
      lng: lngs[index] + (Math.random() - 0.5) * 0.005,
      address: names[index]
    };
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const processFile = (file: File) => {
    if (file && file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setImage(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  // Submit report to express backend
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !description) return;

    setIsSubmitting(true);
    setSubmitStep(1);

    // Multi-stage loader triggers to create premium vibe
    const stepIntervals = [
      setTimeout(() => setSubmitStep(2), 1100),
      setTimeout(() => setSubmitStep(3), 2200),
      setTimeout(() => setSubmitStep(4), 3300),
    ];

    try {
      const token = localStorage.getItem("token");
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      const response = await fetch("/api/issues/report", {
        method: "POST",
        headers,
        body: JSON.stringify({
          title,
          description,
          category,
          lat,
          lng,
          address: address || "SF Coordinates Matrix Point",
          reporterName: reporterName || "Anonymous Sentinel",
          imageUrl: image || undefined
        })
      });

      const data = await response.json();
      
      // Complete loading transition
      setTimeout(() => {
        onIssueCreated(data);
        setIsSubmitting(false);
        // Reset form
        setTitle("");
        setDescription("");
        setAddress("");
        setImage(null);
        setReporterName("");
      }, 4200);

    } catch (err) {
      console.error("Failed to report issue:", err);
      setIsSubmitting(false);
      stepIntervals.forEach(clearTimeout);
    }
  };

  return (
    <div className="rounded-2xl glass-panel p-5 shadow-xl relative overflow-hidden backdrop-blur-xl card-3d-subtle">
      {/* Background ambient lighting overlay */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 blur-3xl rounded-full pointer-events-none" />

      <div className="flex items-center gap-2 mb-4">
        <div className="p-1.5 rounded-lg bg-indigo-500/15 text-indigo-400">
          <Sparkles className="w-4 h-4 animate-pulse" />
        </div>
        <h3 className="font-display text-base font-bold text-slate-100">AI Report Studio</h3>
      </div>

      {isSubmitting ? (
        <div className="py-12 flex flex-col items-center justify-center text-center">
          <div className="relative w-20 h-20 mb-6">
            {/* Spinning holographic circles */}
            <div className="absolute inset-0 rounded-full border-4 border-white/5" />
            <div className="absolute inset-0 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin" />
            <div className="absolute inset-2 rounded-full border-2 border-indigo-300/20 border-b-transparent animate-spin-reverse" />
            <Sparkles className="absolute inset-0 m-auto w-6 h-6 text-indigo-400 animate-pulse" />
          </div>

          <h4 className="text-sm font-display font-semibold text-white mb-2">CIVIC_AI SYNCHRONIZING</h4>
          
          <div className="max-w-xs space-y-2 mt-2">
            <div className={`flex items-center gap-2 text-xs transition-opacity duration-300 ${submitStep >= 1 ? "opacity-100 text-indigo-300" : "opacity-30 text-slate-500"}`}>
              {submitStep > 1 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" /> : <div className="w-2.5 h-2.5 bg-indigo-400 rounded-full animate-ping flex-shrink-0" />}
              <span>Parsing localized threat vectors...</span>
            </div>
            
            <div className={`flex items-center gap-2 text-xs transition-opacity duration-300 ${submitStep >= 2 ? "opacity-100 text-indigo-300" : "opacity-30 text-slate-500"}`}>
              {submitStep > 2 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" /> : <div className="w-2.5 h-2.5 bg-indigo-400 rounded-full animate-ping flex-shrink-0" />}
              <span>Structuring municipal budget brackets...</span>
            </div>

            <div className={`flex items-center gap-2 text-xs transition-opacity duration-300 ${submitStep >= 3 ? "opacity-100 text-indigo-300" : "opacity-30 text-slate-500"}`}>
              {submitStep > 3 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" /> : <div className="w-2.5 h-2.5 bg-indigo-400 rounded-full animate-ping flex-shrink-0" />}
              <span>Simulating 7-day failure risks...</span>
            </div>

            <div className={`flex items-center gap-2 text-xs transition-opacity duration-300 ${submitStep >= 4 ? "opacity-100 text-indigo-300" : "opacity-30 text-slate-500"}`}>
              {submitStep > 4 ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" /> : <div className="w-2.5 h-2.5 bg-indigo-400 rounded-full animate-ping flex-shrink-0" />}
              <span>Injecting beacon to 3D city twin...</span>
            </div>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">Issue Headline</label>
            <input
              type="text"
              required
              placeholder="e.g. Broken Water Pipe near Main Ave"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors backdrop-blur-sm"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-400 transition-colors backdrop-blur-sm"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat} className="bg-slate-900 text-white">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">Reporter Name</label>
              <input
                type="text"
                placeholder="Citizen Hero"
                value={reporterName}
                onChange={(e) => setReporterName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors backdrop-blur-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">Spatial Description & Impact</label>
            <textarea
              required
              rows={3}
              placeholder="Provide a detailed description of the issue. CivicAI will automatically analyze environmental hazards, resolve priorities, and recommend steps."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors resize-none backdrop-blur-sm"
            />
          </div>

          {/* Coordinate Plotter */}
          <div className="bg-white/5 border border-white/10 backdrop-blur-md rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                Location Node
              </span>
              <button
                type="button"
                onClick={triggerGeolocation}
                className="text-[10px] font-mono font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
              >
                <Navigation className="w-3 h-3 animate-pulse" />
                Set Geo Node
              </button>
            </div>

            <input
              type="text"
              placeholder="19th St & Dolores St, San Francisco, CA"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 backdrop-blur-sm"
            />

            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-500">
              <p>LAT: <span className="text-slate-300">{lat.toFixed(6)}</span></p>
              <p>LNG: <span className="text-slate-300">{lng.toFixed(6)}</span></p>
            </div>
          </div>

          {/* File Upload Component */}
          <div>
            <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1.5">Evidence Upload</label>
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
                isDragOver
                  ? "border-indigo-400 bg-indigo-500/10 scale-[0.98]"
                  : "border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileSelect}
                accept="image/*"
                className="hidden"
              />

              {image ? (
                <div className="relative group max-w-xs mx-auto">
                  <img src={image} alt="Evidence preview" className="rounded-lg h-24 w-full object-cover shadow-md border border-white/10" />
                  <div className="absolute inset-0 bg-slate-950/60 rounded-lg opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <span className="text-[10px] font-mono text-white font-bold uppercase">Replace File</span>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center gap-1.5">
                  <Upload className="w-5 h-5 text-slate-500" />
                  <p className="text-xs text-slate-300 font-medium">Drag & drop photo or <span className="text-indigo-400 font-semibold underline">browse</span></p>
                  <p className="text-[10px] text-slate-500">Supports PNG, JPG up to 10MB</p>
                </div>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={!title || !description}
            className="w-full relative overflow-hidden bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold font-display uppercase tracking-wider py-2.5 rounded-xl cursor-pointer shadow-[0_0_15px_rgba(99,102,241,0.5)] transition-all active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100"
          >
            <span className="flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Analyze & Plot Report
            </span>
          </button>
        </form>
      )}
    </div>
  );
};
