import React from "react";
import { Trophy, Medal, Award, Flame, Zap, ArrowUpRight } from "lucide-react";
import { motion } from "motion/react";
import { Hero } from "../types";

interface LeaderboardProps {
  heroes: Hero[];
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ heroes }) => {
  // Sort heroes in descending XP order
  const sortedHeroes = [...heroes].sort((a, b) => b.xp - a.xp);

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Trophy className="w-4 h-4 text-amber-400" />;
      case 1:
        return <Medal className="w-4 h-4 text-slate-300" />;
      case 2:
        return <Award className="w-4 h-4 text-amber-600" />;
      default:
        return <span className="text-[10px] font-mono font-bold text-slate-500">#{index + 1}</span>;
    }
  };

  const getRankBg = (index: number) => {
    switch (index) {
      case 0:
        return "bg-amber-500/10 border-amber-500/20 shadow-[0_0_12px_rgba(245,158,11,0.15)]";
      case 1:
        return "bg-white/10 border-white/20 backdrop-blur-md";
      case 2:
        return "bg-amber-600/10 border-amber-600/20";
      default:
        return "bg-white/5 border border-white/10 backdrop-blur-sm";
    }
  };

  return (
    <div className="rounded-2xl glass-panel p-5 shadow-xl relative overflow-hidden backdrop-blur-xl card-3d-subtle">
      {/* Glow decorative banner */}
      <div className="absolute top-0 left-12 w-20 h-20 bg-emerald-500/5 blur-3xl rounded-full pointer-events-none" />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400">
            <Trophy className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-display text-base font-bold text-slate-100">Community Heroes</h3>
            <p className="text-[10px] text-slate-400 font-mono">ACTIVE_SENTINELS_LEADERBOARD</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/10">
          <Flame className="w-3.5 h-3.5 text-emerald-400 fill-emerald-500/20 animate-pulse" />
          <span>STREAK_ACTIVE</span>
        </div>
      </div>

      <div className="space-y-2.5">
        {sortedHeroes.length === 0 ? (
          <p className="text-xs text-slate-500 font-mono text-center py-4">Plot reports to spawn Hero stats.</p>
        ) : (
          sortedHeroes.map((hero, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.35, delay: Math.min(idx * 0.05, 0.4), ease: "easeOut" }}
              whileHover={{ scale: 1.02, x: -2 }}
              className={`p-3 rounded-xl border flex items-center justify-between transition-all hover:bg-white/10 backdrop-blur-sm ${getRankBg(idx)}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                {/* Placement indicator */}
                <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                  {getRankIcon(idx)}
                </div>

                {/* Avatar */}
                <img
                  src={hero.name === "Linus Tech" ? "https://api.dicebear.com/7.x/pixel-art/svg?seed=Linus" : hero.name === "Linus" ? "https://api.dicebear.com/7.x/pixel-art/svg?seed=Linus" : `https://api.dicebear.com/7.x/pixel-art/svg?seed=${hero.name}`}
                  alt={hero.name}
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-lg bg-white/10 border border-white/20 flex-shrink-0"
                />

                {/* Name & Badge */}
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-slate-200 truncate">{hero.name}</h4>
                  <span className="block text-[9px] font-mono text-indigo-400 uppercase tracking-wide">
                    {hero.badge}
                  </span>
                </div>
              </div>

              {/* XP and report details */}
              <div className="text-right flex-shrink-0">
                <div className="flex items-center justify-end gap-1">
                  <Zap className="w-3 h-3 text-amber-400 fill-amber-500/20" />
                  <span className="text-xs font-mono font-bold text-white">{hero.xp} <span className="text-[10px] text-slate-400 font-normal">XP</span></span>
                </div>
                <p className="text-[9px] text-slate-400 font-mono mt-0.5">
                  R: <span className="text-slate-200 font-bold">{hero.reportsCount}</span> · V: <span className="text-emerald-400 font-bold">{hero.resolutionsCount}</span>
                </p>
              </div>
            </motion.div>
          ))
        )}
      </div>

      <div className="mt-4 border-t border-white/10 pt-3 flex items-center justify-between text-[10px] text-slate-500 font-mono">
        <span>XP resets weekly</span>
        <a href="#rules" className="text-indigo-400 hover:underline flex items-center gap-0.5">
          XP Mechanics
          <ArrowUpRight className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
};
