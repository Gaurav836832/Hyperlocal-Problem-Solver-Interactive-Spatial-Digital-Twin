import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  Mail, 
  Lock, 
  User as UserIcon, 
  LogOut, 
  Award, 
  Clock, 
  CheckCircle, 
  MapPin, 
  Compass, 
  ChevronRight, 
  ShieldCheck, 
  ArrowRight,
  TrendingUp,
  Flame
} from "lucide-react";
import { User, Issue } from "../types";

interface AuthPortalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  onSelectIssue: (issueId: string) => void;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  isOpen,
  onClose,
  currentUser,
  setCurrentUser,
  onSelectIssue
}) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [userIssues, setUserIssues] = useState<Issue[]>([]);
  const [activeTab, setActiveTab] = useState<"profile" | "issues">("profile");

  // Fetch current user's issues if logged in
  useEffect(() => {
    if (currentUser) {
      fetchUserIssues();
    } else {
      setUserIssues([]);
    }
  }, [currentUser]);

  const fetchUserIssues = async () => {
    const token = localStorage.getItem("token");
    if (!token) return;
    try {
      const res = await fetch("/api/auth/profile/issues", {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUserIssues(data);
      }
    } catch (err) {
      console.error("Error fetching user issues:", err);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const url = isRegister ? "/api/auth/register" : "/api/auth/login";
    const body = isRegister ? { name, email, password } : { email, password };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Authentication failed");
      }

      localStorage.setItem("token", data.token);
      setCurrentUser(data.user);
      onClose();
      // Clear forms
      setEmail("");
      setPassword("");
      setName("");
    } catch (err: any) {
      setError(err.message || "An error occurred");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    setCurrentUser(null);
    onClose();
  };

  // Get status class for style
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "resolved": return "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20";
      case "in-progress": return "bg-indigo-500/15 text-indigo-400 border border-indigo-500/20";
      case "verified": return "bg-cyan-500/15 text-cyan-400 border border-cyan-500/20";
      default: return "bg-amber-500/15 text-amber-400 border border-amber-500/20";
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ scale: 0.95, y: 15, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, y: 15, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-slate-900/90 border border-white/10 rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden text-white flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-white/5">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-mono uppercase tracking-wider font-extrabold text-indigo-300">
                  {currentUser ? "CITIZEN_HERO PROFILE" : "MUNICIPAL CONTROL LOG-IN"}
                </h3>
              </div>
              <button 
                onClick={onClose}
                className="p-1 hover:bg-white/10 rounded-lg transition-colors cursor-pointer text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {currentUser ? (
                /* LOGGED IN USER PROFILE */
                <div className="space-y-6">
                  {/* Hero Profile Section */}
                  <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5 relative overflow-hidden">
                    {/* Glowing Accent */}
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-xl rounded-full" />
                    
                    <img 
                      src={currentUser.avatar} 
                      alt={currentUser.name} 
                      className="w-16 h-16 rounded-full border-2 border-indigo-500 shadow-md flex-shrink-0 bg-slate-800"
                    />
                    
                    <div className="space-y-1 z-10">
                      <h4 className="text-base font-extrabold text-slate-100 flex items-center gap-2">
                        {currentUser.name}
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono font-bold flex items-center gap-0.5">
                          <ShieldCheck className="w-3 h-3" /> VERIFIED
                        </span>
                      </h4>
                      <p className="text-xs text-slate-400 font-mono">{currentUser.email}</p>
                      
                      <div className="flex items-center gap-1 text-[11px] font-semibold text-indigo-300">
                        <Award className="w-3.5 h-3.5" />
                        <span>{currentUser.badge}</span>
                      </div>
                    </div>
                  </div>

                  {/* Level & XP progression indicator */}
                  <div className="space-y-2 p-4 rounded-xl bg-slate-950/40 border border-white/5">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-400">Progression Level</span>
                      <span className="text-indigo-400 font-bold">{currentUser.xp} XP</span>
                    </div>
                    {/* Progress bar */}
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 transition-all duration-1000"
                        style={{ width: `${Math.min((currentUser.xp / 1000) * 100, 100)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[9px] text-slate-500 font-mono">
                      <span>0 XP</span>
                      <span>Next Tier: Sentinel Overlord (1000 XP)</span>
                    </div>
                  </div>

                  {/* Activity Stats Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-center space-y-1">
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">Issues Reported</span>
                      <strong className="text-2xl font-extrabold text-slate-100">{userIssues.length}</strong>
                      <span className="text-[9px] text-indigo-400 font-mono block">+50 XP Per Report</span>
                    </div>
                    <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-center space-y-1">
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block">Resolved Cases</span>
                      <strong className="text-2xl font-extrabold text-emerald-400">{userIssues.filter(i => i.status === "resolved").length}</strong>
                      <span className="text-[9px] text-emerald-400 font-mono block">+150 XP Per Fix</span>
                    </div>
                  </div>

                  {/* Tabs Selector */}
                  <div className="flex items-center border-b border-white/10">
                    <button
                      onClick={() => setActiveTab("profile")}
                      className={`flex-1 py-2 text-xs font-mono text-center cursor-pointer transition-all border-b-2 ${
                        activeTab === "profile" 
                          ? "border-indigo-500 text-indigo-400 font-bold" 
                          : "border-transparent text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      ACHIEVEMENTS
                    </button>
                    <button
                      onClick={() => setActiveTab("issues")}
                      className={`flex-1 py-2 text-xs font-mono text-center cursor-pointer transition-all border-b-2 ${
                        activeTab === "issues" 
                          ? "border-indigo-500 text-indigo-400 font-bold" 
                          : "border-transparent text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      MY_REPORTS ({userIssues.length})
                    </button>
                  </div>

                  {/* Tab Contents */}
                  <div className="min-h-[160px]">
                    {activeTab === "profile" ? (
                      /* PROFILE ACHIEVEMENTS TAB */
                      <div className="space-y-3">
                        <div className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400 flex-shrink-0 mt-0.5">
                            <ShieldCheck className="w-4 h-4" />
                          </div>
                          <div>
                            <h5 className="text-xs font-bold text-slate-200">First Responder</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">Awarded for registering with the hyperlocal problem solver grid.</p>
                          </div>
                          <span className="ml-auto text-[10px] text-emerald-400 font-mono font-bold">UNLOCKED</span>
                        </div>

                        <div className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <div className={`p-1.5 rounded-lg flex-shrink-0 mt-0.5 ${
                            currentUser.xp >= 200 ? "bg-purple-500/10 text-purple-400" : "bg-slate-800 text-slate-500"
                          }`}>
                            <TrendingUp className="w-4 h-4" />
                          </div>
                          <div>
                            <h5 className={`text-xs font-bold ${currentUser.xp >= 200 ? "text-slate-200" : "text-slate-500"}`}>City Ranger</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">Unlock Level 2 by earning over 200 XP from reports or community validation.</p>
                          </div>
                          <span className={`ml-auto text-[10px] font-mono font-bold ${
                            currentUser.xp >= 200 ? "text-emerald-400" : "text-slate-500"
                          }`}>
                            {currentUser.xp >= 200 ? "UNLOCKED" : "LOCKED"}
                          </span>
                        </div>

                        <div className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                          <div className={`p-1.5 rounded-lg flex-shrink-0 mt-0.5 ${
                            currentUser.xp >= 600 ? "bg-amber-500/10 text-amber-400" : "bg-slate-800 text-slate-500"
                          }`}>
                            <Flame className="w-4 h-4" />
                          </div>
                          <div>
                            <h5 className={`text-xs font-bold ${currentUser.xp >= 600 ? "text-slate-200" : "text-slate-500"}`}>Legendary Guardian</h5>
                            <p className="text-[10px] text-slate-400 mt-0.5">Reach the highest citizen standing with 600+ XP earned from municipal resolves.</p>
                          </div>
                          <span className={`ml-auto text-[10px] font-mono font-bold ${
                            currentUser.xp >= 600 ? "text-emerald-400" : "text-slate-500"
                          }`}>
                            {currentUser.xp >= 600 ? "UNLOCKED" : "LOCKED"}
                          </span>
                        </div>
                      </div>
                    ) : (
                      /* MY REPORTS SCROLLABLE LIST */
                      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                        {userIssues.length === 0 ? (
                          <div className="text-center py-8 text-slate-500 text-xs">
                            No reported issues found. Go log a hazard on the dashboard!
                          </div>
                        ) : (
                          userIssues.map((issue) => (
                            <div 
                              key={issue.id}
                              onClick={() => {
                                onSelectIssue(issue.id);
                                onClose();
                              }}
                              className="group p-3 rounded-xl bg-white/5 hover:bg-indigo-600/10 border border-white/5 hover:border-indigo-500/20 cursor-pointer transition-all flex items-center justify-between gap-3"
                            >
                              <div className="space-y-1 min-w-0">
                                <h5 className="text-xs font-bold text-slate-200 group-hover:text-indigo-300 transition-colors truncate">
                                  {issue.title}
                                </h5>
                                <div className="flex items-center gap-1.5 text-[9px] text-slate-400">
                                  <Clock className="w-3 h-3" />
                                  <span>{new Date(issue.createdAt).toLocaleDateString()}</span>
                                  <span>·</span>
                                  <MapPin className="w-3 h-3" />
                                  <span className="truncate">{issue.location.address}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2 flex-shrink-0">
                                <span className={`text-[9px] uppercase font-mono px-2 py-0.5 rounded-full font-bold ${getStatusBadgeClass(issue.status)}`}>
                                  {issue.status}
                                </span>
                                <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-indigo-400 transition-colors" />
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>

                  {/* Logout Button */}
                  <button
                    onClick={handleLogout}
                    className="w-full bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/20 text-rose-400 hover:text-rose-300 py-2.5 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    TERMINATE_SESSION
                  </button>
                </div>
              ) : (
                /* LOGIN / REGISTER FORM PANEL */
                <form onSubmit={handleAuthSubmit} className="space-y-4">
                  {error && (
                    <div className="p-3 bg-rose-500/15 border border-rose-500/20 rounded-xl text-rose-400 text-xs text-center font-mono animate-shake">
                      ERROR: {error}
                    </div>
                  )}

                  {isRegister && (
                    <div className="space-y-1.5">
                      <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider flex items-center gap-1">
                        <UserIcon className="w-3.5 h-3.5" /> Full Name
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. John Doe"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-sans text-white focus:outline-none focus:border-indigo-500 transition-all"
                      />
                    </div>
                  )}

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider flex items-center gap-1">
                      <Mail className="w-3.5 h-3.5" /> Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. hero@community.org"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-sans text-white focus:outline-none focus:border-indigo-500 transition-all"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400 uppercase font-mono tracking-wider flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" /> Password
                    </label>
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs font-sans text-white focus:outline-none focus:border-indigo-500 transition-all"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-xl text-xs font-mono tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-indigo-600/30"
                  >
                    {loading ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        {isRegister ? "REGISTER_HERO" : "INITIATE_SESSION"}
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="text-center pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setIsRegister(!isRegister);
                        setError(null);
                      }}
                      className="text-xs text-indigo-400 hover:text-indigo-300 font-mono transition-colors cursor-pointer"
                    >
                      {isRegister 
                        ? "Already have verification? Login here" 
                        : "New reporter? Register active profile"}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
