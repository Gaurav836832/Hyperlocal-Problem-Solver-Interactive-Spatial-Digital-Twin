import React, { useState, useRef, useEffect } from "react";
import { MessageSquare, Send, Sparkles, AlertCircle, FileText, HeartHandshake, User, Bot, HelpCircle } from "lucide-react";
import { Issue, ChatMessage } from "../types";

interface CivicAIPlannerProps {
  selectedIssue: Issue | null;
  isNightMode: boolean;
}

export const CivicAIPlanner: React.FC<CivicAIPlannerProps> = ({ selectedIssue, isNightMode }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: "ai",
      text: "Greetings, Citizen! I am CivicAI, your neighborhood digital planning counselor. Select any active issue in the list or map, and click below to instantly organize neighborhood taskforces, draft petition emails to municipal managers, or simulate safety checklists.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto scroll
  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Handle send message
  const handleSend = async (textToSend?: string) => {
    const msgText = textToSend || input;
    if (!msgText.trim() || isLoading) return;

    if (!textToSend) setInput("");

    const newMsg: ChatMessage = {
      sender: "user",
      text: msgText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, newMsg]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/ai/planner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msgText,
          issueContextId: selectedIssue?.id || undefined
        })
      });

      const data = await response.json();

      const aiMsg: ChatMessage = {
        sender: "ai",
        text: data.reply || "I encountered a minor grid disruption. Please retry.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error("AI Planner fetch failed:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Pre-configured helper shortcuts
  const handleShortcut = (type: "petition" | "cleanup" | "safety") => {
    if (!selectedIssue) {
      handleSend(`General guidelines on how to organize a local ${type === 'petition' ? 'council petition' : type === 'cleanup' ? 'park cleanup drive' : 'street hazard safety guide'}.`);
      return;
    }

    switch (type) {
      case "petition":
        handleSend(`Please draft an official, polite petition email to the municipal director regarding the issue: "${selectedIssue.title}" located at ${selectedIssue.location.address}. Please include standard civil codes and requesting signatures.`);
        break;
      case "cleanup":
        handleSend(`Create a step-by-step community organization checklist and task allocation plan for organizing a weekend group cleanup/repair for the issue: "${selectedIssue.title}".`);
        break;
      case "safety":
        handleSend(`What are the immediate physical safety precautions, makeshift signs, and hazard containment actions our neighborhood group should establish for the issue: "${selectedIssue.title}"?`);
        break;
    }
  };

  // Safe client-side custom formatting of AI markdown response (bolding, lists, linebreaks)
  const renderMessageText = (text: string) => {
    const lines = text.split("\n");
    return lines.map((line, idx) => {
      // Check for bullet lists
      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        return (
          <li key={idx} className="ml-4 list-disc pl-1 text-slate-300 text-xs my-0.5 font-sans leading-relaxed">
            {formatBoldText(line.replace(/^[-*]\s+/, ""))}
          </li>
        );
      }
      // Check for numbered lists
      const numMatch = line.trim().match(/^(\d+)\.\s+(.*)/);
      if (numMatch) {
        return (
          <li key={idx} className="ml-4 list-decimal pl-1 text-slate-300 text-xs my-0.5 font-sans leading-relaxed">
            {formatBoldText(numMatch[2])}
          </li>
        );
      }
      // Check for major heading blocks
      if (line.trim().startsWith("###")) {
        return (
          <h5 key={idx} className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-wider mt-3 mb-1">
            {line.replace(/^###\s+/, "")}
          </h5>
        );
      }
      if (line.trim().startsWith("##")) {
        return (
          <h4 key={idx} className="text-xs font-display font-bold text-white border-b border-slate-900 pb-1 mt-4 mb-2">
            {line.replace(/^##\s+/, "")}
          </h4>
        );
      }
      if (line.trim().startsWith("#")) {
        return (
          <h3 key={idx} className="text-sm font-display font-bold text-indigo-300 mt-4 mb-2">
            {line.replace(/^#\s+/, "")}
          </h3>
        );
      }
      // General paragraph
      if (line.trim() === "") {
        return <div key={idx} className="h-2" />;
      }
      return (
        <p key={idx} className="text-slate-200 text-xs leading-relaxed font-sans my-1">
          {formatBoldText(line)}
        </p>
      );
    });
  };

  const formatBoldText = (str: string) => {
    const parts = str.split(/\*\*(.*?)\*\*/g);
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return <strong key={i} className="text-indigo-300 font-semibold">{part}</strong>;
      }
      // Check for code bits inline `code`
      const codeParts = part.split(/`(.*?)`/g);
      return codeParts.map((sub, j) => {
        if (j % 2 === 1) {
          return <code key={j} className="bg-slate-950 px-1 py-0.5 rounded text-[11px] font-mono text-cyan-400 border border-slate-900">{sub}</code>;
        }
        return sub;
      });
    });
  };

  return (
    <div className="rounded-2xl glass-panel h-[480px] flex flex-col overflow-hidden shadow-2xl relative backdrop-blur-xl card-3d-subtle">
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/10 bg-white/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
          <div>
            <h4 className="text-xs font-display font-bold text-slate-100 flex items-center gap-1">
              <Bot className="w-3.5 h-3.5 text-indigo-400" />
              CivicAI Planner
            </h4>
            <p className="text-[10px] text-slate-400 font-mono">MODEL_STATUS: ONLINE</p>
          </div>
        </div>
        <HelpCircle className="w-4 h-4 text-slate-500 cursor-help" />
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-3 max-w-[90%] ${msg.sender === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
            {/* Avatar */}
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 ${
              msg.sender === 'ai' ? 'bg-indigo-950 border border-indigo-500/20 text-indigo-400' : 'bg-slate-800 text-slate-300'
            }`}>
              {msg.sender === 'ai' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
            </div>

            {/* Message Box */}
            <div className={`rounded-2xl px-4 py-3 text-xs backdrop-blur-md ${
              msg.sender === 'ai' 
                ? 'bg-white/5 border border-white/10 text-slate-100' 
                : 'bg-indigo-500/80 border border-white/10 text-white rounded-tr-none shadow-[0_0_12px_rgba(99,102,241,0.3)]'
            }`}>
              {msg.sender === 'ai' ? (
                <div className="space-y-1">{renderMessageText(msg.text)}</div>
              ) : (
                <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>
              )}
              <span className={`block text-[9px] mt-1.5 font-mono text-right ${
                msg.sender === 'ai' ? 'text-slate-500' : 'text-indigo-200'
              }`}>
                {msg.timestamp}
              </span>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-3 max-w-[90%]">
            <div className="w-7 h-7 rounded-lg bg-indigo-950 border border-indigo-500/20 text-indigo-400 flex items-center justify-center animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="rounded-2xl px-4 py-3.5 bg-white/5 border border-white/10 flex items-center gap-2">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest">Compiling Civic Plan...</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Target Issue Context Indicator */}
      {selectedIssue && (
        <div className="px-4 py-2 border-t border-white/10 bg-white/5 flex items-center justify-between text-[11px] animate-fade-in">
          <div className="flex items-center gap-1.5 text-indigo-300">
            <AlertCircle className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
            <span className="font-medium truncate">Context Active: <strong className="text-white">{selectedIssue.title}</strong></span>
          </div>
          <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold flex-shrink-0">
            {selectedIssue.category}
          </span>
        </div>
      )}

      {/* Shortcuts Selector */}
      <div className="px-4 py-2 bg-white/5 border-t border-white/10 flex items-center gap-2 overflow-x-auto">
        <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider flex-shrink-0">Templates:</span>
        <button
          onClick={() => handleShortcut("petition")}
          className="text-[10px] font-mono font-medium hover:text-white px-2.5 py-1 rounded bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1 cursor-pointer transition-all flex-shrink-0 hover:bg-white/10"
        >
          <FileText className="w-3 h-3 text-orange-400" />
          Council Petition
        </button>
        <button
          onClick={() => handleShortcut("cleanup")}
          className="text-[10px] font-mono font-medium hover:text-white px-2.5 py-1 rounded bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1 cursor-pointer transition-all flex-shrink-0 hover:bg-white/10"
        >
          <HeartHandshake className="w-3 h-3 text-emerald-400" />
          Cleanup Checklist
        </button>
        <button
          onClick={() => handleShortcut("safety")}
          className="text-[10px] font-mono font-medium hover:text-white px-2.5 py-1 rounded bg-white/5 border border-white/10 text-slate-300 flex items-center gap-1 cursor-pointer transition-all flex-shrink-0 hover:bg-white/10"
        >
          <AlertCircle className="w-3 h-3 text-rose-400" />
          Safety Precautions
        </button>
      </div>

      {/* Text Input Block */}
      <div className="p-3 border-t border-white/10 bg-white/5 flex items-center gap-2">
        <input
          type="text"
          placeholder={selectedIssue ? "Ask about coordinating this issue..." : "Ask CivicAI about community planning..."}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors backdrop-blur-sm"
        />
        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || isLoading}
          className="p-2 bg-indigo-500/80 border border-white/10 hover:bg-indigo-500 text-white rounded-xl transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed shadow-[0_0_10px_rgba(99,102,241,0.4)]"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
