import React from "react";
import { ShieldAlert, CheckCircle2, TrendingUp, BarChart3, Radio, HelpCircle, Activity } from "lucide-react";
import { motion } from "motion/react";
import { CommunityStats } from "../types";

interface ImpactDashboardProps {
  stats: CommunityStats | null;
}

export const ImpactDashboard: React.FC<ImpactDashboardProps> = ({ stats }) => {
  if (!stats) return null;

  const { summary, predictiveTrend } = stats;

  return (
    <div className="space-y-4">
      {/* Dynamic Stat Meters Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Metric 1 */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.05 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg relative overflow-hidden flex flex-col gap-1.5 card-3d-subtle"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Total Reports</span>
            <Activity className="w-4 h-4 text-indigo-400" />
          </div>
          <h3 className="text-xl font-display font-bold text-white leading-none">
            {summary.total}
          </h3>
          <div className="flex items-center gap-1.5 text-[10px] text-indigo-400/80 font-mono mt-1">
            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-ping" />
            <span>ACTIVE_LOGS</span>
          </div>
        </motion.div>

        {/* Metric 2 */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg relative overflow-hidden flex flex-col gap-1.5 card-3d-subtle"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">In Progress</span>
            <Radio className="w-4 h-4 text-cyan-400" />
          </div>
          <h3 className="text-xl font-display font-bold text-white leading-none">
            {summary.inProgress + summary.verified}
          </h3>
          <div className="flex items-center gap-1.5 text-[10px] text-cyan-400/80 font-mono mt-1">
            <span className="w-1.5 h-1.5 bg-cyan-500 rounded-full animate-pulse" />
            <span>VOLUNTEERS_ENGAGED</span>
          </div>
        </motion.div>

        {/* Metric 3 */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.15 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg relative overflow-hidden flex flex-col gap-1.5 card-3d-subtle"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Resolved</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-xl font-display font-bold text-white leading-none">
            {summary.resolved}
          </h3>
          <div className="flex items-center gap-1.5 text-[10px] text-emerald-400/80 font-mono mt-1">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
            <span>XP_GRANTED</span>
          </div>
        </motion.div>

        {/* Metric 4 */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          whileHover={{ y: -4, scale: 1.02 }}
          className="p-3.5 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md shadow-lg relative overflow-hidden flex flex-col gap-1.5 card-3d-subtle"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Resolution Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-xl font-display font-bold text-white leading-none">
            {summary.resolutionRate}%
          </h3>
          {/* Simple horizontal progress bar */}
          <div className="w-full bg-white/10 rounded-full h-1 mt-2 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${summary.resolutionRate}%` }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="bg-gradient-to-r from-emerald-500 to-indigo-500 h-1 rounded-full"
            />
          </div>
        </motion.div>
      </div>

      {/* Glowing AI Spatial Insights Panel */}
      <motion.div 
        whileHover={{ scale: 1.005 }}
        className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-xl relative overflow-hidden shadow-xl holographic-card glowing-card card-3d-subtle"
      >
        {/* Subtle decorative scanner grid line */}
        <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none" />

        <div className="flex items-center gap-2 mb-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
          <span className="text-[10px] font-mono text-indigo-400 uppercase tracking-widest font-bold">
            CivicAI Predictive Spatial Analytics
          </span>
        </div>

        <p className="text-xs text-slate-200 leading-relaxed font-sans">
          {predictiveTrend}
        </p>

        <div className="mt-2 text-[9px] font-mono text-slate-400 border-t border-white/10 pt-1.5 flex items-center justify-between">
          <span>COORDINATE_TENSION: LOW</span>
          <span>DENSE_MODEL_RUNS: 32</span>
        </div>
      </motion.div>
    </div>
  );
};
