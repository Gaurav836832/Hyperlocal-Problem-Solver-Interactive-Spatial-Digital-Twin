import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MapPin,
  Sparkles,
  ShieldAlert,
  CheckCircle2,
  ThumbsUp,
  Layers,
  Flame,
  RefreshCw,
  Sun,
  Moon,
  Eye,
  BookOpen,
  Award,
  Navigation,
  Check,
  Building,
  Activity,
  ChevronRight,
  Info
} from "lucide-react";
import { Issue, CommunityStats, User } from "./types";
import { CityDigitalTwin } from "./components/CityDigitalTwin";
import { ReportStudio } from "./components/ReportStudio";
import { CivicAIPlanner } from "./components/CivicAIPlanner";
import { Leaderboard } from "./components/Leaderboard";
import { ImpactDashboard } from "./components/ImpactDashboard";
import { AuthPortal } from "./components/AuthPortal";

export default function App() {
  // Live State
  const [issues, setIssues] = useState<Issue[]>([]);
  const [selectedIssueId, setSelectedIssueId] = useState<string | null>(null);
  const [stats, setStats] = useState<CommunityStats | null>(null);

  // User Auth States
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Map Filter/Views
  const [isNightMode, setIsNightMode] = useState(true);
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showBuildings, setShowBuildings] = useState(true);
  
  // UI States
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [revealAiDrawerId, setRevealAiDrawerId] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Auto-authenticate on load
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      fetch("/api/auth/me", {
        headers: { "Authorization": `Bearer ${token}` }
      })
      .then(res => {
        if (res.ok) return res.json();
        else throw new Error("Invalid session token");
      })
      .then(user => setCurrentUser(user))
      .catch(() => {
        localStorage.removeItem("token");
        setCurrentUser(null);
      });
    }
  }, []);

  // Fetch baseline issues & stats
  const fetchIssuesAndStats = async () => {
    setIsRefreshing(true);
    try {
      const [issuesRes, statsRes] = await Promise.all([
        fetch("/api/issues"),
        fetch("/api/community/stats")
      ]);
      const issuesData = await issuesRes.json();
      const statsData = await statsRes.json();

      setIssues(issuesData);
      setStats(statsData);
      
      // Select first issue as default if none selected
      if (issuesData.length > 0 && !selectedIssueId) {
        setSelectedIssueId(issuesData[0].id);
      }
    } catch (err) {
      console.error("Failed to fetch community data:", err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchIssuesAndStats();
  }, []);

  // Vote / Verify callback
  const handleVerify = async (id: string) => {
    try {
      const response = await fetch(`/api/issues/${id}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: currentUser?.id || "anonymous-citizen" })
      });
      if (response.ok) {
        const updatedIssue = await response.json();
        // Update local issues list
        setIssues(prev => prev.map(i => i.id === id ? updatedIssue : i));
        // Refresh community stats / leaderboard
        const statsRes = await fetch("/api/community/stats");
        const statsData = await statsRes.json();
        setStats(statsData);

        // Sync XP on client side in real-time
        if (localStorage.getItem("token")) {
          fetch("/api/auth/me", {
            headers: { "Authorization": `Bearer ${localStorage.getItem("token")}` }
          })
          .then(res => res.ok ? res.json() : null)
          .then(user => {
            if (user) setCurrentUser(user);
          })
          .catch(console.error);
        }
      } else {
        const errData = await response.json();
        alert(errData.error || "Failed to verify report.");
      }
    } catch (err) {
      console.error("Error voting on issue:", err);
    }
  };

  // Resolve issue callback
  const handleResolve = async (id: string) => {
    try {
      const response = await fetch(`/api/issues/${id}/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      if (response.ok) {
        const updatedIssue = await response.json();
        setIssues(prev => prev.map(i => i.id === id ? updatedIssue : i));
        
        // Re-fetch stats
        const statsRes = await fetch("/api/community/stats");
        const statsData = await statsRes.json();
        setStats(statsData);

        // Sync XP on client side in real-time
        if (localStorage.getItem("token")) {
          fetch("/api/auth/me", {
            headers: { "Authorization": `Bearer ${localStorage.getItem("token")}` }
          })
          .then(res => res.ok ? res.json() : null)
          .then(user => {
            if (user) setCurrentUser(user);
          })
          .catch(console.error);
        }
      }
    } catch (err) {
      console.error("Error resolving issue:", err);
    }
  };

  // On new report created
  const handleIssueCreated = (newIssue: Issue) => {
    setIssues(prev => [newIssue, ...prev]);
    setSelectedIssueId(newIssue.id);
    setRevealAiDrawerId(newIssue.id);
    
    // Refresh stats
    fetch("/api/community/stats")
      .then(res => res.json())
      .then(data => setStats(data));

    // Sync XP on client side in real-time after reporting
    if (localStorage.getItem("token")) {
      fetch("/api/auth/me", {
        headers: { "Authorization": `Bearer ${localStorage.getItem("token")}` }
      })
      .then(res => res.ok ? res.json() : null)
      .then(user => {
        if (user) setCurrentUser(user);
      })
      .catch(console.error);
    }
  };

  const selectedIssue = issues.find(i => i.id === selectedIssueId) || null;

  // Filter Issues list based on query and category selector
  const filteredIssues = issues.filter(issue => {
    const matchesSearch = 
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === "All" || issue.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const categories = [
    "All",
    "Roads & Transit",
    "Water Supply",
    "Public Safety",
    "Waste Management",
    "Environment & Parks",
    "Power & Grid"
  ];

  return (
    <div className={`min-h-screen font-sans transition-colors duration-500 relative overflow-x-hidden ${
      isNightMode ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-800"
    }`}>
      {/* Ambient Mesh Gradient Background Layers */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/15 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/15 blur-[120px] rounded-full" />
        <div className="absolute top-[40%] right-[10%] w-[40%] h-[40%] bg-purple-600/10 blur-[130px] rounded-full" />
      </div>

      {/* Top Cybernetic Status Bar */}
      <div className="bg-indigo-600 text-white text-[11px] font-mono py-1.5 px-4 text-center flex items-center justify-between shadow-inner relative z-20">
        <span className="flex items-center gap-1.5 font-bold uppercase tracking-widest">
          <Activity className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
          COMMUNITY_SENTINEL NETWORK ACTIVE
        </span>
        <div className="flex items-center gap-3">
          <span>SF DISTRICT 5 · DIGITAL TWIN FEED</span>
          <span className="hidden sm:inline-block">UTC: {new Date().toISOString().substring(11, 19)}</span>
        </div>
      </div>

      {/* Main Core Header */}
      <header className={`border-b px-4 py-4 md:px-8 flex flex-col md:flex-row items-center justify-between gap-4 relative z-20 backdrop-blur-md ${
        isNightMode ? "border-white/10 bg-white/5" : "border-slate-200/80 bg-white/70"
      }`}>
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-emerald-500 flex items-center justify-center shadow-lg">
            <Award className="w-5.5 h-5.5 text-white animate-pulse" />
            <div className="absolute -inset-0.5 bg-gradient-to-br from-indigo-600 to-emerald-500 rounded-xl blur opacity-30" />
          </div>
          <div>
            <h1 className="text-lg md:text-xl font-display font-extrabold tracking-tight flex items-center gap-1.5">
              <span>Community Hero</span>
              <span className="text-xs bg-indigo-500/10 text-indigo-400 border border-indigo-500/10 font-mono px-2 py-0.5 rounded-full font-bold">PRO MAX</span>
            </h1>
            <p className="text-xs text-slate-400">Hyperlocal Problem Solver · Interactive Spatial Digital Twin</p>
          </div>
        </div>

        {/* Global Control Toggles */}
        <div className="flex items-center flex-wrap gap-2">
          {/* User Profile / Auth Toggler */}
          <button
            onClick={() => setIsAuthOpen(true)}
            className={`p-1.5 px-3 rounded-xl border flex items-center gap-2 text-xs font-mono transition-all cursor-pointer ${
              isNightMode 
                ? "bg-indigo-600/10 border-indigo-500/30 text-indigo-300 hover:bg-indigo-600/20 backdrop-blur-sm" 
                : "bg-indigo-50 border-indigo-200 text-indigo-700 hover:bg-indigo-100"
            }`}
          >
            {currentUser ? (
              <>
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name} 
                  className="w-5 h-5 rounded-full border border-indigo-500 bg-slate-800"
                />
                <span className="hidden sm:inline font-bold text-slate-200">{currentUser.name.toUpperCase()} ({currentUser.xp} XP)</span>
              </>
            ) : (
              <>
                <Award className="w-4 h-4 text-indigo-400" />
                <span>CITIZEN_LOGIN</span>
              </>
            )}
          </button>

          {/* Night/Day Toggler */}
          <button
            onClick={() => setIsNightMode(!isNightMode)}
            className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-mono transition-all cursor-pointer ${
              isNightMode 
                ? "bg-white/5 border-white/10 text-yellow-400 hover:bg-white/10 backdrop-blur-sm" 
                : "bg-white border-slate-200 text-indigo-600 hover:bg-slate-50"
            }`}
          >
            {isNightMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            <span className="hidden sm:inline">{isNightMode ? "LIGHT_MODE" : "NIGHT_MODE"}</span>
          </button>

          {/* Refresh Action */}
          <button
            onClick={fetchIssuesAndStats}
            disabled={isRefreshing}
            className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-mono transition-all cursor-pointer ${
              isNightMode ? "bg-white/5 border-white/10 hover:bg-white/10 backdrop-blur-sm text-slate-300" : "bg-white border-slate-200 hover:bg-slate-50 text-slate-600"
            }`}
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">SYNC_DATA</span>
          </button>
        </div>
      </header>

      {/* Main Structural Grid Section with 3D entry animation and perspective mapping */}
      <motion.main 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-7xl mx-auto px-4 py-6 md:px-6 space-y-6 relative z-10 perspective-1000"
      >
        
        {/* UPPER ROW: Spatial 3D Map + Layers + Quick stats */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main 3D Digital Twin Viewer (Col Span 2) */}
          <div className="lg:col-span-2 flex flex-col gap-3 card-3d">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4.5 h-4.5 text-indigo-400" />
                <h2 className="font-display text-sm font-extrabold tracking-wider uppercase text-slate-300">Holographic 3D Digital Twin</h2>
              </div>

              {/* 3D Map Layer Controls */}
              <div className="flex items-center gap-1.5 bg-white/5 p-1 rounded-xl border border-white/10 backdrop-blur-md">
                <button
                  onClick={() => setShowBuildings(!showBuildings)}
                  className={`px-3 py-1 text-[10px] font-mono rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    showBuildings 
                      ? "bg-indigo-500/80 border border-white/10 text-white font-bold shadow-[0_0_12px_rgba(99,102,241,0.4)]" 
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Building className="w-3.5 h-3.5" />
                  Buildings
                </button>
                <button
                  onClick={() => setShowHeatmap(!showHeatmap)}
                  className={`px-3 py-1 text-[10px] font-mono rounded-lg flex items-center gap-1 transition-all cursor-pointer ${
                    showHeatmap 
                      ? "bg-indigo-500/80 border border-white/10 text-white font-bold shadow-[0_0_12px_rgba(99,102,241,0.4)]" 
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  Heat Overlay
                </button>
              </div>
            </div>

            {/* Canvas Container */}
            <div className="h-[380px] md:h-[450px]">
              <CityDigitalTwin
                issues={issues}
                selectedIssueId={selectedIssueId}
                onSelectIssue={(id) => {
                  setSelectedIssueId(id);
                  // Auto reveal AI insights when clicking map beacons
                  setRevealAiDrawerId(id);
                }}
                isNightMode={isNightMode}
                showHeatmap={showHeatmap}
                showBuildings={showBuildings}
              />
            </div>
          </div>

          {/* Side Panel: Active Issues List Feed */}
          <div className="flex flex-col gap-3 h-full">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-sm font-extrabold tracking-wider uppercase text-slate-300">Live Reports Feed</h2>
              <span className="text-[10px] font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/10">
                {filteredIssues.length} ISSUES
              </span>
            </div>

            {/* Search and Category Filtering Module */}
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Search report descriptions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-400 backdrop-blur-sm transition-colors"
              />
              
              {/* Category selector row */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`text-[10px] font-mono px-2.5 py-1 rounded-lg transition-all cursor-pointer whitespace-nowrap border ${
                      selectedCategory === cat
                        ? "bg-indigo-500/80 text-white border-white/20 font-bold shadow-[0_0_12px_rgba(99,102,241,0.4)]"
                        : "bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Scrollable Issues Feed */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-2.5 max-h-[380px] md:max-h-[420px] lg:max-h-[450px]">
              {filteredIssues.length === 0 ? (
                <div className="py-12 text-center rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md flex flex-col items-center justify-center gap-2">
                  <ShieldAlert className="w-8 h-8 text-slate-500 animate-pulse" />
                  <p className="text-xs text-slate-400 font-mono">No matching localized hazards found.</p>
                </div>
              ) : (
                filteredIssues.map((issue, idx) => {
                  const isActive = issue.id === selectedIssueId;
                  return (
                    <motion.div
                      key={issue.id}
                      initial={{ opacity: 0, y: 15, rotateX: -5 }}
                      animate={{ opacity: 1, y: 0, rotateX: 0 }}
                      transition={{ duration: 0.4, delay: Math.min(idx * 0.04, 0.4), ease: "easeOut" }}
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedIssueId(issue.id)}
                      className={`p-3.5 rounded-xl border backdrop-blur-md transition-all cursor-pointer flex flex-col gap-2 ${
                        isActive
                          ? "bg-white/10 border-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.3)] text-white"
                          : "bg-white/5 border-white/5 hover:border-white/15 hover:bg-white/10 text-slate-300"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 uppercase">
                          {issue.category}
                        </span>
                        
                        <span className={`text-[9px] uppercase font-mono font-bold ${
                          issue.severity === "critical" ? "text-rose-400" :
                          issue.severity === "high" ? "text-orange-400" : "text-cyan-400"
                        }`}>
                          {issue.severity}
                        </span>
                      </div>

                      <h4 className="text-xs font-bold font-display text-slate-100">{issue.title}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{issue.description}</p>
                      
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                        <MapPin className="w-3.5 h-3.5 text-slate-600 flex-shrink-0" />
                        <span className="truncate">{issue.location.address}</span>
                      </div>

                      {/* Vote & Resolve Actions inside individual issue card */}
                      <div className="border-t border-white/10 pt-2.5 mt-1 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleVerify(issue.id);
                            }}
                            className="flex items-center gap-1 text-[10px] font-mono text-indigo-300 bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 transition-all cursor-pointer shadow-[0_0_10px_rgba(255,255,255,0.02)]"
                          >
                            <ThumbsUp className="w-3 h-3 text-indigo-400" />
                            <span>Verify ({issue.votes})</span>
                          </button>
                          
                          {issue.status !== "resolved" ? (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleResolve(issue.id);
                              }}
                              className="flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-white/5 hover:bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 transition-all cursor-pointer shadow-[0_0_10px_rgba(255,255,255,0.02)]"
                            >
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span>Resolve</span>
                            </button>
                          ) : (
                            <span className="text-[9px] uppercase font-mono font-bold text-emerald-400 bg-white/10 border border-white/10 px-2.5 py-1 rounded-lg flex items-center gap-0.5">
                              <Check className="w-3 h-3" />
                              RESOLVED
                            </span>
                          )}
                        </div>

                        {/* Reveal AI Insights button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedIssueId(issue.id);
                            setRevealAiDrawerId(revealAiDrawerId === issue.id ? null : issue.id);
                          }}
                          className="text-[10px] font-mono font-semibold text-slate-400 hover:text-white flex items-center gap-0.5 cursor-pointer"
                        >
                          <Sparkles className="w-3 h-3 text-indigo-400" />
                          AI Brief
                          <ChevronRight className="w-3 h-3 text-slate-500" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })
              )}
            </div>
          </div>
        </section>

        {/* AI INSIGHTS DRAWER: Smooth dropdown display below selected issue */}
        <AnimatePresence>
          {selectedIssue && revealAiDrawerId === selectedIssue.id && selectedIssue.aiInsights && (
            <motion.section
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="p-5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-2xl relative shadow-2xl">
                {/* Decorative background visual elements */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 blur-3xl rounded-full pointer-events-none" />
                
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-indigo-500/15 text-indigo-400 rounded-xl border border-white/10">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="font-display text-sm font-extrabold tracking-wider text-slate-100 uppercase">
                        AI Hazard Assessment & Action Blueprint
                      </h3>
                      <p className="text-[10px] text-slate-400 font-mono uppercase">
                        Target Report Node: {selectedIssue.id}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="bg-white/5 border border-white/10 backdrop-blur-md rounded-xl px-3 py-1.5 text-right">
                      <p className="text-[9px] font-mono text-slate-400 uppercase">Civic Priority</p>
                      <p className="text-sm font-mono font-bold text-indigo-400">
                        {selectedIssue.aiInsights.priorityScore}/100
                      </p>
                    </div>

                    <div className="bg-white/5 border border-white/10 backdrop-blur-md rounded-xl px-3 py-1.5 text-right">
                      <p className="text-[9px] font-mono text-slate-400 uppercase">Estimated Repair Budget</p>
                      <p className="text-sm font-mono font-bold text-emerald-400">
                        {selectedIssue.aiInsights.estimatedCost}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Summary Columns */}
                  <div className="md:col-span-1 space-y-4">
                    <div>
                      <h4 className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                        <Info className="w-3.5 h-3.5 text-indigo-400" />
                        AI Executive Summary
                      </h4>
                      <p className="text-xs text-slate-200 leading-relaxed font-sans">
                        {selectedIssue.aiInsights.summary}
                      </p>
                    </div>

                    <div className="p-3 bg-rose-500/5 rounded-xl border border-rose-500/20 backdrop-blur-sm">
                      <h4 className="text-[10px] font-mono text-rose-400 uppercase tracking-wider mb-1 flex items-center gap-1.5 font-bold">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        7-Day Failure Projection
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed font-sans">
                        {selectedIssue.aiInsights.escalationPrediction}
                      </p>
                    </div>
                  </div>

                  {/* Suggested steps list column */}
                  <div className="md:col-span-2 space-y-2">
                    <h4 className="text-[10px] font-mono text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Step-by-Step Resolution Blueprint
                    </h4>
                    <div className="space-y-2">
                      {selectedIssue.aiInsights.suggestedSteps.map((step, idx) => (
                        <div key={idx} className="p-3 bg-white/5 border border-white/10 backdrop-blur-sm rounded-xl flex items-start gap-3 hover:bg-white/10 transition-all">
                          <span className="w-5 h-5 rounded bg-indigo-500/10 border border-white/10 text-[10px] font-mono font-bold text-indigo-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <p className="text-xs text-slate-200 leading-relaxed">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* MIDDLE SECTION: Reporting Studio + CivicAI Chat Planner */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ReportStudio onIssueCreated={handleIssueCreated} isNightMode={isNightMode} />
          
          <CivicAIPlanner selectedIssue={selectedIssue} isNightMode={isNightMode} />
        </section>

        {/* BOTTOM SECTION: Community stats dashboard and gamified Leaderboards */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ImpactDashboard stats={stats} />
          </div>
          
          <div>
            {stats && <Leaderboard heroes={stats.leaderboard} />}
          </div>
        </section>

      </motion.main>

      {/* Futuristic footer credits */}
      <footer className={`border-t py-6 mt-12 text-center text-xs font-mono text-slate-500 relative z-10 backdrop-blur-md ${
        isNightMode ? "border-white/10 bg-white/5" : "border-slate-200 bg-white"
      }`}>
        <p>© 2026 Community Hero Network · SF District 5 Digital Twin Operations.</p>
        <p className="mt-1 text-[10px] text-slate-600">Powered by server-side Gemini 3.5 Flash & Antigravity Intelligence.</p>
      </footer>

      {/* User Authentication & Profile Portal Portal */}
      <AuthPortal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={currentUser}
        setCurrentUser={setCurrentUser}
        onSelectIssue={(id) => {
          setSelectedIssueId(id);
          setRevealAiDrawerId(id);
        }}
      />
    </div>
  );
}
